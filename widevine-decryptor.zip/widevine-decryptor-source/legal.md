"This is for educational purposes only. Downloading copyrighted materials from streaming services may violate their Terms of Service. **Use at your own risk.**"

Even after writing this, Google still pitched a fit. Because as of 11.09.20, they've DCMA'd almost every fork of this project. Even with our notices that we intend these for educational purposes, they still don't care. They're hell bent on censoring everything that crosses their path.

No more.

I'm done watching thousands be censored and silenced. I'm done being controlled by a company who's always selling me out for ads. I'm done with the lack of humanity and respect that we should be getting as humans. I'm tired of being a stack of cash, a pile of ads waiting to be served up.

So Google? Come on, go ahead. Come after me and everyone else for reverse-engineering your DRM scheme. We'll just come back. We'll keep on fighting for the education that we're trying to provide, the anti-censorship, the anti-silencing. We won't back down, because we fight for our rights as humans and what we do. We'll fight for our work and other's educations, because you may be taking down things that enable piracy, but you're also preventing others from creating new things by seeing how your DRM works.

And this won't just be another fork where I copy and do nothing. I'm going to work on this project and make sure it works on Linux and macOS. I'm going to back it up every step of the way so that even if you try to take me down, I'll just come back up.

So let's fight, Google. Let's fight, Microsoft. Or Facebook. Anyone who doesn't understand that the open-source world does what it has to do to educate, create, and build.

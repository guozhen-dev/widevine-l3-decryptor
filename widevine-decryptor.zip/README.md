# To the Bitter End

We're the open-source community, and we don't take no for an answer.
